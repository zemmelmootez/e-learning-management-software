package com.example.projet;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.stage.Modality;

import java.security.PublicKey;
import java.time.LocalDate;

public class StudentComponent {

    public VBox StudentVbox(){


        Image img = new Image("C:\\Users\\HP\\Desktop\\projet\\src\\main\\resources\\Search.png");
        HBox hbox=new HBox();

        Label CoursesList=new Label("Courses List");
        TextField searchText=new TextField();
        searchText.setPromptText("Search");
        searchText.setStyle("-fx-background-color: transparent; -fx-background-insets: 0; -fx-border-width: 0;");
        searchText.setBorder(Border.EMPTY);

        HBox hsearch=new HBox();
        ImageView isearch=new ImageView(img);
        hsearch.setStyle("-fx-background-insets: 20;-fx-border-color:#B5D6F6; -fx-border-width: 1;-fx-border-radius:20");
        hsearch.setAlignment(Pos.CENTER);
        isearch.setFitWidth(12);
        hsearch.setPadding(new Insets(5));
        isearch.setPreserveRatio(true);
        hsearch.getChildren().addAll(isearch,searchText);

        CoursesList.setTextFill(Paint.valueOf("#717171"));
        CoursesList.setFont(new Font("Arial",20));

        hbox.getChildren().addAll(CoursesList,hsearch);
        hbox.setSpacing(400);
        hbox.setAlignment(Pos.TOP_RIGHT);
        HBox hbutton=new HBox();
        Button Consult=new Button("Add Student");
        Consult.setStyle("-fx-background-color:#56A2EC;-fx-text-fill:white;");
        hbutton.getChildren().addAll(Consult);
        hbutton.setPadding(new Insets(20));
        hbutton.setAlignment(Pos.TOP_RIGHT);
// partie centre
        VBox vbox = new VBox();

        GridPane gridPane = new GridPane();

        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(20);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPercentWidth(30);
        ColumnConstraints col3 = new ColumnConstraints();
        col3.setPercentWidth(20);
        ColumnConstraints col4 = new ColumnConstraints();
        col4.setPercentWidth(20);
        ColumnConstraints col5 = new ColumnConstraints();
        col4.setPercentWidth(20);
        gridPane.getColumnConstraints().addAll(col1, col2, col3, col4, col5);

// Add nodes to the grid
        gridPane.add(new Label("Name"), 0, 0);
        gridPane.add(new Label("Email"), 1, 0);
        gridPane.add(new Label("Course"), 2, 0);
        gridPane.add(new Label("Subscription Date"), 3, 0);

        HBox edit = new HBox();
        ImageView editimg = new ImageView(new Image("C:\\Users\\HP\\Desktop\\projet\\src\\main\\resources\\Edit.png"));
        ImageView supimg = new ImageView(new Image("C:\\Users\\HP\\Desktop\\projet\\src\\main\\resources\\sup.png"));
        edit.getChildren().addAll(editimg, supimg);
        edit.setSpacing(10);

        //implementation graphique
        gridPane.add(new Label("John Doe"), 0, 1);
        gridPane.add(new Label("johndoe@example.com"), 1, 1);
        gridPane.add(new Label("Java Programming"), 2, 1);
        gridPane.add(new Label("2022-03-30"), 3, 1);
        gridPane.add(edit, 4, 1);
        gridPane.setPadding(new Insets(0,0,0,100));

        gridPane.setHgap(5);
        gridPane.setVgap(5);
        vbox.setSpacing(14);
        vbox.getChildren().addAll(hbox,hbutton, gridPane);

        Consult.setOnAction(actionEvent ->
        {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("add student");
            alert.getDialogPane().setHeader(null);
            alert.setHeaderText(null);
            alert.setContentText(null);
            alert.getDialogPane().setGraphic(null);

            Label courseLabel = new Label("Student Name:");
            courseLabel.setStyle("-fx-font-size: 17px");
            TextField courseTextField = new TextField();
            courseTextField.setStyle("-fx-background-radius: 9px; -fx-background-color: #EDEDED;-fx-text-fill: black ;-fx-font-size: 15px;");
            courseTextField.setPromptText("Enter name");
            courseTextField.setMinHeight(30);

            Label instructorLabel = new Label("Student Email:");
            instructorLabel.setStyle("-fx-font-size: 17px");
            TextField instructorTextField = new TextField();
            instructorTextField.setStyle("-fx-background-radius: 9px; -fx-background-color: #EDEDED;-fx-text-fill: black ;-fx-font-size: 15px;");
            instructorTextField.setPromptText("Enter Email");
            instructorTextField.setMinHeight(30);

            // Create submit button
            Button submitButton = new Button("Submit");
            submitButton.setStyle("-fx-background-color: #56A2EC;-fx-text-fill: #FFFFFF; -fx-font-size: 17px");
            // Create layout and add components
            VBox layout = new VBox();
            layout.setSpacing(10);
          //  layout.setPadding(new Insets(20, 30, 20, 30));
            layout.setPrefHeight(200);

            layout.getChildren().addAll(courseLabel, courseTextField,
                    instructorLabel, instructorTextField,
                    submitButton);

            // Set layout properties
            layout.setAlignment(Pos.CENTER_LEFT);

            layout.setStyle("-fx-background-color: white; -fx-border-radius: 9px; -fx-border-color: #c9c9c9; -fx-border-width: 1px;");

            // Create the alert dialog
            alert.getDialogPane().setContent(layout);
            alert.showAndWait();
        }
        );

            return vbox;




    }
}
